from django.db import models

class Usuario(models.Model):
    cedula = models.CharField(max_length=10, unique=True)
    

class Candidato(models.Model):
    nombre = models.CharField(max_length=100)
    lista = models.CharField(max_length=50)

class Voto(models.Model):
    votante = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    candidato_elegido = models.ForeignKey(Candidato, on_delete=models.CASCADE)

class Lista(models.Model):
    nombre = models.CharField(max_length=50)
