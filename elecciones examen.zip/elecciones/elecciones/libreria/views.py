from django.shortcuts import render
from django.http import HttpResponse

def inicio(request):
    return HttpResponse('brinvenido')
    
    
def nosotros(request):
        return render(request,'paginas/nosotros')
from django.shortcuts import render, redirect
from .models import Usuario, Candidato

def inicio(request):
    return render(request, 'inicio.html')

def ingresar(request):
    if request.method == 'POST':
        cedula = request.POST['cedula']
        try:
            usuario = Usuario.objects.get(cedula=cedula)
            return redirect('mostrar_candidatos')
        except Usuario.DoesNotExist:
            return render(request, 'ingresar.html', {'error': 'Usuario no encontrado'})
    return render(request, 'ingresar.html')

def mostrar_candidatos(request):
    candidatos = Candidato.objects.all()
    return render(request, 'candidatos.html', {'candidatos': candidatos})

def votar(request):

    return  render(request, 'votar.html')

def mostrar(request):
    
    return render(request, 'resultados.html')
