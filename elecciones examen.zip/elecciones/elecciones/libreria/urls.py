from django.urls import path
from. import views
from django.urls import path

urlpatterns = [
    
    path('',views.inicio,name='inicio'),
    path( 'nosotros', views.nosotros, name='nosotros' ),
    path('ingresar/', views.ingresar, name='ingresar'),
    path('candidatos/', views.mostrar_candidatos, name='mostrar_candidatos'),
    path('votar/', views.votar, name='votar'),
    path('mostrar/', views.mostrar, name='mostrar'),
   
]