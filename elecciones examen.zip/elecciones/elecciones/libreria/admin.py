from django.contrib import admin
from.models import Candidato,Usuario,Voto,Lista,Usuario

admin.site.register(Candidato)
admin.site.register(Usuario)
admin.site.register(Voto)
admin.site.register(Lista)

# Register your models here.
